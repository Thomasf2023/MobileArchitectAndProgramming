package com.example.cs360project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.ContactsContract;

import com.example.cs360project2.DatabaseHelper;

import java.sql.SQLDataException;

public class DatabaseManager {
    //Variables
    private DatabaseHelper dbHelper;
    private Context context;
    private static SQLiteDatabase database;

    public DatabaseManager(Context ctx){
        context = ctx;
    }

    public DatabaseManager open() throws SQLDataException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    //The following code is used for entering data into the database.
    public void insertUsernamePassword(String username, String password){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.USER_NAME, username);
        contentValues.put(DatabaseHelper.USER_PASSWORD, password);
        database.insert(DatabaseHelper.DATABASE_TABLE, null, contentValues);

    }
    public void insertSunWeight(String weight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.SUN_WEIGHT, weight);
        database.insert(DatabaseHelper.DATABASE_TABLE, null, contentValues);

    }
    public void insertMonWeight(String weight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.MON_WEIGHT, weight);
        database.insert(DatabaseHelper.DATABASE_TABLE, null, contentValues);

    }
    public void insertTueWeight(String weight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.TUE_WEIGHT, weight);
        database.insert(DatabaseHelper.DATABASE_TABLE, null, contentValues);

    }
    public void insertWedWeight(String weight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.WED_WEIGHT, weight);
        database.insert(DatabaseHelper.DATABASE_TABLE, null, contentValues);

    }
    public void insertThuWeight(String weight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.THU_WEIGHT, weight);
        database.insert(DatabaseHelper.DATABASE_TABLE, null, contentValues);

    }
    public void insertFriWeight(String weight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.FRI_WEIGHT, weight);
        database.insert(DatabaseHelper.DATABASE_TABLE, null, contentValues);

    }
    public void insertSatWeight(String weight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.SAT_WEIGHT, weight);
        database.insert(DatabaseHelper.DATABASE_TABLE, null, contentValues);

    }
    //The following code is the fetch functions for my Database manager. Each one will intialize variables, call a cursor to do a query and return the cursor
    public Cursor fetchNamePass(String id, String name, String password){
        id = DatabaseHelper.USER_ID;
        name = DatabaseHelper.USER_NAME;
        password = DatabaseHelper.USER_PASSWORD;

        String [] columns = new String[] {id, name, password};
        Cursor cursor = database.query(DatabaseHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }
    public static Cursor fetchSunWeight(){
        String [] columns = new String [] {DatabaseHelper.SUN_WEIGHT};
        Cursor cursor = database.query(DatabaseHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public static Cursor fetchMonWeight(){
        String [] columns = new String [] {DatabaseHelper.MON_WEIGHT};
        Cursor cursor = database.query(DatabaseHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public static Cursor fetchTueWeight(){
        String [] columns = new String [] {DatabaseHelper.TUE_WEIGHT};
        Cursor cursor = database.query(DatabaseHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public static Cursor fetchWedWeight(){
        String [] columns = new String [] {DatabaseHelper.WED_WEIGHT};
        Cursor cursor = database.query(DatabaseHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public static Cursor fetchThuWeight(){
        String [] columns = new String [] {DatabaseHelper.THU_WEIGHT};
        Cursor cursor = database.query(DatabaseHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public static Cursor fetchFriWeight(){
        String [] columns = new String [] {DatabaseHelper.FRI_WEIGHT};
        Cursor cursor = database.query(DatabaseHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }
    public static Cursor fetchSatWeight(){
        String [] columns = new String [] {DatabaseHelper.SAT_WEIGHT};
        Cursor cursor = database.query(DatabaseHelper.DATABASE_TABLE, columns, null, null, null, null, null);
        if (cursor != null){
            cursor.moveToFirst();
        }
        return cursor;
    }

    public int updateNamePass(long _id, String username, String password){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.USER_NAME, username);
        contentValues.put(DatabaseHelper.USER_PASSWORD, password);
        int ret = database.update(DatabaseHelper.DATABASE_TABLE, contentValues, DatabaseHelper.USER_ID + "=" + _id, null);
        return ret;
    }
    public int updateSunWeight(long _id, String userWeight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.SUN_WEIGHT, userWeight);
        int ret = database.update(DatabaseHelper.DATABASE_TABLE, contentValues, DatabaseHelper.USER_ID + "=" + _id, null);
        return ret;
    }
    public int updateMonWeight(long _id, String userWeight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.MON_WEIGHT, userWeight);
        int ret = database.update(DatabaseHelper.DATABASE_TABLE, contentValues, DatabaseHelper.USER_ID + "=" + _id, null);
        return ret;
    }
    public int updateTueWeight(long _id, String userWeight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.TUE_WEIGHT, userWeight);
        int ret = database.update(DatabaseHelper.DATABASE_TABLE, contentValues, DatabaseHelper.USER_ID + "=" + _id, null);
        return ret;
    }
    public int updateWedWeight(long _id, String userWeight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.WED_WEIGHT, userWeight);
        int ret = database.update(DatabaseHelper.DATABASE_TABLE, contentValues, DatabaseHelper.USER_ID + "=" + _id, null);
        return ret;
    }
    public int updateThuWeight(long _id, String userWeight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.THU_WEIGHT, userWeight);
        int ret = database.update(DatabaseHelper.DATABASE_TABLE, contentValues, DatabaseHelper.USER_ID + "=" + _id, null);
        return ret;
    }
    public int updateFriWeight(long _id, String userWeight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.FRI_WEIGHT, userWeight);
        int ret = database.update(DatabaseHelper.DATABASE_TABLE, contentValues, DatabaseHelper.USER_ID + "=" + _id, null);
        return ret;
    }
    public int updateSatWeight(long _id, String userWeight){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.SAT_WEIGHT, userWeight);
        int ret = database.update(DatabaseHelper.DATABASE_TABLE, contentValues, DatabaseHelper.USER_ID + "=" + _id, null);
        return ret;
    }

    public SQLiteDatabase getDatabase() {
        return database;
    }
}
