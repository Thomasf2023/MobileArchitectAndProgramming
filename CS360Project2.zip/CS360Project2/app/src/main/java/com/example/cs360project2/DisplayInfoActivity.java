package com.example.cs360project2;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class DisplayInfoActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_info);

        //The following code will intialize the cursor, fetch the weight of the day, convert the cursor to a string, and display the string in the edit text

        //Sunday
        Cursor cursor = DatabaseManager.fetchSunWeight();

        if (cursor.moveToFirst()){
            String string = cursor.getString(cursor.getColumnIndexOrThrow("SUN_WEIGHT"));
            EditText editText = findViewById(R.id.editTextText3);
            editText.setText(string);
        }

        //Monday
        cursor = DatabaseManager.fetchMonWeight();

        if (cursor.moveToFirst()){
            String string = cursor.getString(cursor.getColumnIndexOrThrow("MON_WEIGHT"));
            EditText editText = findViewById(R.id.editTextText3);
            editText.setText(string);
        }
        //Tuesday
        cursor = DatabaseManager.fetchTueWeight();

        if (cursor.moveToFirst()){
            String string = cursor.getString(cursor.getColumnIndexOrThrow("TUE_WEIGHT"));
            EditText editText = findViewById(R.id.editTextText3);
            editText.setText(string);
        }
        //Wednesday
        cursor = DatabaseManager.fetchWedWeight();

        if (cursor.moveToFirst()){
            String string = cursor.getString(cursor.getColumnIndexOrThrow("WED_WEIGHT"));
            EditText editText = findViewById(R.id.editTextText3);
            editText.setText(string);
        }
        //Thursday
        cursor = DatabaseManager.fetchThuWeight();

        if (cursor.moveToFirst()){
            String string = cursor.getString(cursor.getColumnIndexOrThrow("THU_WEIGHT"));
            EditText editText = findViewById(R.id.editTextText3);
            editText.setText(string);
        }
        //Friday
        cursor = DatabaseManager.fetchFriWeight();

        if (cursor.moveToFirst()){
            String string = cursor.getString(cursor.getColumnIndexOrThrow("FRI_WEIGHT"));
            EditText editText = findViewById(R.id.editTextText3);
            editText.setText(string);
        }
        //Saturday
        cursor = DatabaseManager.fetchSatWeight();

        if (cursor.moveToFirst()){
            String string = cursor.getString(cursor.getColumnIndexOrThrow("SAT_WEIGHT"));
            EditText editText = findViewById(R.id.editTextText3);
            editText.setText(string);
        }
    }


}