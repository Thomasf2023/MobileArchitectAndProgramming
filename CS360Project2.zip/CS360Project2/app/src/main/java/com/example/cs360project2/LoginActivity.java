package com.example.cs360project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    EditText username;
    EditText password;
    DatabaseManager dbManager;

    String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //Intialize variables
        username = (EditText) findViewById(R.id.editTextText);
        password = (EditText) findViewById(R.id.editTextText2);
        dbManager = new DatabaseManager(this);

        try { //Try to open Database manager
            dbManager.open();
        }
        catch (Exception e){ //Exception throw if manager does not open
            e.printStackTrace();
        }
    }
    public void createAccount(View v){ //Function for "Create Account" button to use
        dbManager.insertUsernamePassword(username.getText().toString(), password.getText().toString());
        User user = new User();
        Intent myIntent = new Intent(this, DisplayInfoActivity.class);
        startActivity(myIntent);
    }
    public void login(View v) throws Exception { //Function for "Login" button to user
        SQLiteDatabase myDB = dbManager.getDatabase();

        //This code will fetch the id, name and password of the user and make sure that they match.
        //The user does not need to enter an ID, it is automatically given to each user when their account is created as a way to verify their information.
        if ((dbManager.fetchNamePass(id, username.getText().toString(), password.getText().toString()) != null)){
            Intent myIntent = new Intent(this, DisplayInfoActivity.class);
            startActivity(myIntent);
        }
        else {
            throw new Exception ("Invalid username or password"); //Throws exception if data is invalid
        }


    }
}