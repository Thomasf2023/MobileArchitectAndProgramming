package com.example.cs360project2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    static final String DATABASE_NAME = "WEIGHT_TRACKER.DB";
    static final int DATABASE_VERSION = 1;

    static final String DATABASE_TABLE = "USERS";
    static final String USER_ID = "_ID";
    static final String USER_NAME = "user_name";
    static final String USER_PASSWORD = "password";
    static final String SUN_WEIGHT = "sunday_weight";
    static final String MON_WEIGHT = "monday_weight";
    static final String TUE_WEIGHT = "tuesday_weight";
    static final String WED_WEIGHT = "wednesday_weight";
    static final String THU_WEIGHT = "thursday_weight";
    static final String FRI_WEIGHT = "friday_weight";
    static final String SAT_WEIGHT = "saturday_weight";

    private static final String CREATE_DB_QUERY = "CREATE TABLE " + DATABASE_TABLE + "(" + USER_ID + "INTEGER PRIMARY KEY AUTOINCREMENT, " +
            USER_NAME + " TEXT," +
            USER_PASSWORD + "TEXT," +
            SUN_WEIGHT + "TEXT," +
            MON_WEIGHT + "TEXT," +
            TUE_WEIGHT + "TEXT," +
            WED_WEIGHT + "TEXT," +
            THU_WEIGHT + "TEXT," +
            FRI_WEIGHT + "TEXT," +
            SAT_WEIGHT + "TEXT)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_DB_QUERY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
    }
}
